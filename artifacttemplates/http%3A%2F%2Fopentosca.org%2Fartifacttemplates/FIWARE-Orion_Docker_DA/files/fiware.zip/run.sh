#!/bin/bash
mongod & /usr/bin/contextBroker -fg -multiservice