package org.opentosca.implementationartifacts;

public class CredentialsFormatException extends Exception {

	private static final long serialVersionUID = -7346446078364876344L;

	public CredentialsFormatException(String string) {
		super(string);
	}

}